
public class UserInfo {
	private static int userId;
	public int getUserId() {
		return userId;
	}
	public int setUserId(int customer_id) {
		 this.userId = customer_id;
		 return this.userId;
	}
}
